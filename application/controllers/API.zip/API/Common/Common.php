<?php
require APPPATH.'/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Common extends REST_Controller

{
    public function __construct()
    {
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        parent::__construct();
        $this->load->database();
        $this->load->model('Api_model');
        $this->load->library('Authorization_Token');
    }
    
    public function httpOk($messageNumber, $responseMessage)
    {
        $response['status']='success';
        $response['code']=REST_Controller::HTTP_OK;
        $response['messageNumber']=$messageNumber;
        $response['response_message']=$responseMessage;
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function httpOkGetResponse($responseMessage)
    {
        $response['status']='success';
        $response['code']=REST_Controller::HTTP_OK;
        $response['response_message']=$responseMessage;
        $this->response($response, REST_Controller::HTTP_OK);
    }

    public function httpNotFound($errorNumber, $responseMessage)
    {
        $response['status']='failure';
        $response['code']=REST_Controller::HTTP_NOT_FOUND;
        $response['errorNumber']=$errorNumber;
        $response['response_message']=$responseMessage;
        $this->response($response, REST_Controller::HTTP_NOT_FOUND);

    }

    public function emailbody($sendfrom, $to, $subject, $message)
    {
        $this->load->view('mailactive/index');
        sendmails($sendfrom, $to, $message, $subject);
    }
   

}