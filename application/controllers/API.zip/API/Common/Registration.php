<?php
require APPPATH.'/controllers/API/Common/Common.php';

class Registration extends Common 
{
    public function addregistrationuser_post()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = trim($data["mobilenumber"])??"";
        $email = trim($data["email"])??"";
        if ($mobile!='') {
            if ($email!='') {
                $getvalidateemail=$this->Api_model->validemail($email, $mobile);
        
                if ($getvalidateemail>0) {
                    $this->httpOk('MSG_200_005', MSG_200_005);
                } else {
                    $asp=array();
                    $keytable=array();
                    $user_profile=array();
                    $asp_emp=array();
                    $comm=array();
                    $user_temp=array();
        
                    $type = trim($data["type"])??"";
                    $firstName = trim($data["firstname"])??"";
                    $aspLastName = trim($data["lastname"])??"";
                    $asp['TYPE_OF_REGISTRATION']=$type;
                    $asp['First_Name']= $firstName;
                    $asp['Last_Name']=$lastName;
                    $asp['Mobile_No']=$mobile;
                    $asp['E_Mail']=$email;
                    $date=date('Y-m-d H:s:i');
                    $asp['Record_Inserted_Dttm']=$date;
                    $userId=$this->asp_emp_id();
                    $keytable['ID']=$userId;
                    $keytable['RECORD_INSERTED_DTTM']=$date;
                    $keytable['Source_Key']=$email;
                    $asp_emp['USER_ID']=$userId;
                    $asp_emp['RECORD_INSERTED_DTTM']=$date;
                    $asp_emp['ACTIVE_STATUS']=YES;
                    $asp_emp['Referral_Code']=$refrenceCode;
                    $asp_emp['First_Name']= $firstName;
                    $asp_emp['Last_Name']=$lastName;
                    $refrenceCode=trim($data["refrencecode"])??"";
                    $asp['Referral_Code']=$refrenceCode;
                    $comm['USER_ID']=$userId;
                    $comm['Mobile_No']= $mobile;
                    $comm['E_Mail']=$email;
                    $comm['RECORD_INSERTED_DTTM']=$date;
                    $comm['ACTIVE_STATUS']=NO;
        
                    if ($type==EMPLOYER||$type==ASPIRANT) {
                        if ($type==ASPIRANT) {
                            $profile='P';
                            $seniority  = trim($data["seniority"])??"";
                            $displayName  = trim($data["displayname"])??"";
                            $profileId  = trim($data["profileid"])??"";
                            $catId  = trim($data["catid"])??"";
                            $subcatId  = trim($data["subcatid"])??"";
                            $profileIdd  = trim($data["profileidd"])??"";
        
                            $asp['Seniority']= $seniority;
                            $asp['Display_Name']=$displayName;
                            $asp['Referral_Code']=$refrenceCode;
                            $asp['Primary_Profile_Name']=$profileId;
                            $asp['Category_Name']=$catId ;
                            $asp['Sub_Category_Name']= $subcatId;
        
                            $keytable['Type_ID']=ASPIRANT;
          
                            $asp_emp['Display_Name']=$displayName;
                            $asp_emp['Seniority']=$seniority;
                            $asp_emp['Applicant_Access'] =YES;
                            $asp_emp['Recruiter_Access']=NO;
                            $asp_emp['Referral_Code']=$refrenceCode;
            
                            $user_profile['USER_ID']=$userId;
                            $user_profile['Category_ID']=$this->Api_model->get_cat_id($asp['Category_Name']);
                            $user_profile['Sub_Category_ID']=$this->Api_model->get_subcat_id($asp['Sub_Category_Name']);
                            $user_profile['PROFILE_ID']=$this->Api_model->get_profile_id($asp['Primary_Profile_Name']);
                            $user_profile['PROFILE_TYPE']=$profile;
        
                            $user_temp['Profile_Id']=$profileIdd;
                            $user_temp['USER_ID']=$userId;
                            $user_temp['Is_Primary']=$profile;
        
                            $getvalue=$this->Api_model->aspregistration($asp, $keytable, $user_profile, $asp_emp, $comm, $user_temp);
                            $this->httpOk('MSG_200_006', MSG_200_006);
                        } else {
                            $asp['Represents']=trim($_REQUEST['empcat']);
                            $asp['Address']=trim($_REQUEST['address']);
                            $asp['State']=trim($_REQUEST['state']);
                            $asp['City']=trim($_REQUEST['city']);
                            $asp['Company_Name']=trim($_REQUEST['companyfirm']);
                            $asp['Website']=trim($_REQUEST['website']);
                            $keytable['Type_ID']=EMPLOYER;
                            $asp_emp['Recruiter_Represents']=trim($_REQUEST['empcat']);
                            $asp_emp['Company_Name']=trim($_REQUEST['companyfirm']);
                            $asp_emp['Website']=trim($_REQUEST['website']);
                            $asp_emp['Applicant_Access'] =NO;
                            $asp_emp['Recruiter_Access']=YES;
                            $comm['State']=trim($_REQUEST['state']);
                            $comm['City']=trim($_REQUEST['city']);
                            $comm['Permanent_Address']=trim($_REQUEST['address']);
                            $getvalue=$this->Api_model->aspregistration($asp, $keytable, '', $asp_emp, $comm, '');
                            $this->httpOk('MSG_200_007', MSG_200_007);
                        }
                    }
                    $subject='Successfully Registered With '.WEBSITE_NAME.' As '.$type;
                    $mess='';
                    $mess.='<p>Dear '.$asp['First_Name'].' '.$asp['Last_Name'].'</p>';
                    $mess.='<p>You are successfully registered with CastIndia as a <strong>'.$type.'</strong>. Please click <a href='.base_url().'home/emailverify?token='.base64_encode($asp['Mobile_No']).'>Here</a> to verify your email</p>';
                    $mess.='<p>Regards,<br> <strong>Team '.WEBSITE_NAME.'</strong> </p>';
                    $message=$mess;
                    $this->emailbody(REGISTRATION_EMAIL,$asp['E_Mail'],$subject,$message);
                }
            } else {
                $this->httpNotFound('EN_404_002', EN_404_002);
            }
        } else {
            $this->httpNotFound('EN_404_003', EN_404_003);
        }
    }

}