<?php
require APPPATH.'/controllers/API/Common/Common.php';

class DashboardAdditionalForm  extends Common 
{

    public function getcityStateByPincode_post(){
        $data = json_decode(file_get_contents('php://input'), true);
        $pincode=trim($data["pincode"])??"";
        if ($pincode!='') {
            $getcityStateByPincode['cityStateByPincode']=$this->Api_model->getGeoCode($pincode);
            $this->httpOkGetResponse($getcityStateByPincode);
        }else{
            $this->httpNotFound('EN_404_004', EN_404_004);
        }
    }
}