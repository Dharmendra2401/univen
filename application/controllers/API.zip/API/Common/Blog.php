<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends Common {

	public function indexBlogList_post()
	{
		
		$data = json_decode(file_get_contents('php://input'), true);
		$blogLimit=trim($data["bloglimit"])??"5";
		$sliderLimit=trim($data["sliderlimit"])??"5";
		$categoryid=trim($data["categoryid"])??"";	
	    $blogcategory['blogcategory']=$this->ApiBlogModel->getBlogCategory();;
		$blogs['blogs']=$this->ApiBlogModel->getBlogList($categoryid);
		$bloglimits['bloglimits']=$this->ApiBlogModel->getBlogLimit($blogLimit);;
		$blogsliders['blogsliders']=$this->ApiBlogModel->getBlogLimit($sliderLimit);
		$alldata=array_merge_recursive($blogcategory,$blogs,$bloglimits,$blogsliders);
		$this->httpOkGetResponse($alldata);
	
	}
	
	public function blogDetails_post()
	{ 	
		$data = json_decode(file_get_contents('php://input'), true);
		$blogLimit=trim($data["bloglimit"])??"5";
		$sliderLimit=trim($data["sliderlimit"])??"5";
		$id=trim($data["id"])??"";
	    $blogcategory['blogcategory']=$this->ApiBlogModel->getBlogCategory("");
		$blogs['blogs']=$this->ApiBlogModel->getBlogList();
		$blogdetails['blogdetails'] = $this->ApiBlogModel->getBlogDetail($id);
		$bloglimits['bloglimits'] =  $this->ApiBlogModel->getBlogLimit($blogLimit);
		$blogsliders['blogsliders']=$this->ApiBlogModel->getBlogLimit($sliderLimit);
		$alldata=array_merge_recursive($blogdetails,$blogcategory,$blogs,$bloglimits,$blogsliders);
		$this->httpOkGetResponse($alldata);
		
	}
	public function blogComment_post(){
		$data = json_decode(file_get_contents('php://input'), true);
		$userdata['name'] = trim($data["name"])??"";
        $userdata['email'] = trim($data["email"])??"";
		$userdata['website'] = trim($data["website"])??""; 
        $userdata['comment'] = trim($data["comment"])??"";
		$userdata['blog_id'] =trim($data["blogid"])??"";
        $page_data['save_blog_insertid'] = $this->ApiBlogModel->save_blogcomment($userdata);
		$this->httpOkGetResponse($page_data['save_blog_insertid']);
		
      
	}
	public function searchParam_post(){
		$data = json_decode(file_get_contents('php://input'), true);
		$blogLimit=trim($data["bloglimit"])??"5";
		$sliderLimit=trim($data["sliderlimit"])??"5";
		$id=trim($data["id"])??"";
        $title = trim($data["blogtitle"])??"";
	    $blogcategory['blogcategory']=$this->ApiBlogModel->getBlogCategory("");
		$blogs['blogs']=$this->ApiBlogModel->getBlogList();
		$bloglimits['bloglimits']= $this->ApiBlogModel->getBlogLimit($blogLimit);;
		$blogsliders['blogsliders']=$this->ApiBlogModel->getBlogLimit($sliderLimit);
		$blogdetails['blogdetails'] = $this->ApiBlogModel->getBlogDetail($id);
        $search_param['search_param'] = $this->ApiBlogModel->getSearchBlog($title);
	    $alldata=array_merge_recursive($blogcategory,$blogs,$bloglimits,$blogsliders);
		$this->httpOkGetResponse($alldata);
		
    }
	
}