<?php
require APPPATH.'/controllers/API/Common/Common.php';

class Login extends Common
{
    public function mobileverification_post()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $mobile = trim($data["mobilenumber"])??"";
        $type = trim($data["type"])??"";

        if ($mobile!='') {
            if ($type==EMPLOYER||$type==ASPIRANT) {
                $getvalue=$this->Api_model->validMobileLogin($mobile, $type);
                if ($getvalue>0) {
                    $getaspdetails=$this->Api_model->getLoginUserDetails($mobile, $type);
                    $mobilenumber='91'.$mobile;
                    $otp= mt_rand(1000, 9999);
                    $apiKey = urlencode('NzAzN2M4ODJhODQ5YTVhNTJkNWQxY2ExZmMwZGJjYzU=');
                    //Message details
                    $numbers = array($mobilenumber);
                    $sender = urlencode('GLCAIN');
                    if (($type==ASPIRANT)||($type==EMPLOYER)) {
                        $message = rawurlencode('The One Time Password (OTP) for Cast India login is '.$otp.'. Please use this OTP to login. It is only valid for 01:00 minutes. Do not share this code with anyone for security reasons.');
                    } else {
                        $message = rawurlencode('The One Time Password (OTP) for registration at Cast India is '.$otp.'. Do not share this code with anyone for security reasons.');
                    }
                    $numbers = implode(',', $numbers);
                    //   Prepare data for POST request
                    $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
                    // Send the POST request with cURL
                    $ch = curl_init('https:api.textlocal.in/send/');
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_exec($ch);
                    curl_close($ch);
                    // $token_data['user_id'] = 600;
                    // $token_data['fullname'] = 'euifhuilgfrwe';
                    // $token_data['email'] = 'ertertre@gmail.com';
                    // $tokenData = $this->authorization_token->generateToken($token_data);
                    if ($getaspdetails['Mobile_No']!='') {
                        $response['mobile_no']=$getaspdetails['Mobile_No'];
                        $response['user_id']=$getaspdetails['USER_ID'];
                        $response['email']=$getaspdetails['E_Mail'];
                        $response['first_name']=$getaspdetails['First_Name'];
                        $response['last_anme']=$getaspdetails['Last_Name'];
                        $response['profile_pic']=$getaspdetails['Profile_Pic'];
                        $response['type']=$getaspdetails['Type_ID'];
                    }
                    $response['otp']=$otp;
                    $this->httpOk('MSG_200_001', MSG_200_001);
                } else {
                    $this->httpOk('MSG_200_002', MSG_200_002);
                }
            } else {
                $this->httpNotFound('EN_404_001', EN_404_001);
            }
        } else {
            $this->httpNotFound('EN_404_002', EN_404_002);
        }
    }
}