<?php
require APPPATH.'/controllers/API/Common/Common.php';

class Empregisteration extends Common 
{
    public function getemployerinputdetails_get()
    {
        $getstates['getstates']=$this->Api_model->state();
        $getempcat['getempcat']=$this->Api_model->getemployercat();
        $getall=array_merge_recursive($getempcat, $getstates);
        $this->httpOkGetResponse($getall);
    }

}